import React from 'react'
export default function App(){
  return (<div style={{padding:20,fontFamily:'Inter,Arial'}}><h2>MegaGPT Vite App (Demo)</h2><p>Use this scaffold to call /api/generate-av and play media.</p></div>)
}
